# Imputation Report

- Generated: 2025-08-12T13:14:08.335939
- Rows: 7461
- Cols: 30

## Selection (per column)
```json
{
  "event_previous_timestamp": {
    "method": "median",
    "metrics": {
      "MAE": 1151079566686.991,
      "runtime_sec": 0.013427257537841797
    },
    "dtype": "numeric"
  }
}
```
